<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2021 Amasty (https://www.amasty.com)
 * @package Amasty_Feed
 */


namespace Amasty\Feed\Model\Rule\Condition;

/**
 * Class ProductFactory
 */
class ProductFactory extends \Magento\CatalogRule\Model\Rule\Condition\ProductFactory
{
}
